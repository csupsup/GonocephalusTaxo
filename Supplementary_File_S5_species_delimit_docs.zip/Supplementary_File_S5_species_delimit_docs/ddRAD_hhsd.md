# HHSD using RAD Loci

### Data Needed
* DNA sequences
* Pop map file
* Guide tree
* Control file

**A. Data prep: RAD loci sequences in Phylip format**

In R, use the filtered VCF file to generate a PHYLIP file with sequence data for all filtered loci (including invariant sites) for samples that passed all filtering protocols.
```r
library(vcfR)

## Read vcf file with filtered, unlinked loci
vcfR<-read.vcfR("data/gono_outgroup_75snps_thinned.vcf")

## Check the metadata
head(vcfR@fix)

## Isolate the third column, which contains the name of each locus
head(vcfR@fix[,1])

## Get a list of just locus names to use as whitelist for stacks
whitelist<-sub(":.*", "", vcfR@fix[,1])

## Make sure each locus is unique
length(unique(whitelist)) == length(whitelist)

## Check locus names
whitelist[1:5]

## Write whitelist for stacks
write.table(whitelist, file = "whitelist.txt", quote = F, row.names = F, col.names = F)
```

Generate popmap including only the samples in the filtered vcf file, assigning each sample to a unique pop so that we keep all tips distinct. Note that phylip format limits names to 10 characters.
```r
## <ake population names <10 characters
colnames(vcfR@gt)[-1]

## With multiple acronyms like KU FMNH or RBM
gsub(".*(KU_\\d+|FMNH_\\d+|RMB_\\d+|UPLBMNH_\\d+|ACD_\\d+|CDS_\\d+|EMD_\\d+|JAM_\\d+).*", "\\1", colnames(vcfR@gt)[-1])

p <- gsub(".*(KU_\\d+|FMNH_\\d+|RMB_\\d+|UPLBMNH_\\d+|ACD_\\d+|CDS_\\d+|EMD_\\d+|JAM_\\d+).*", "\\1", colnames(vcfR@gt)[-1])

## Make a popmap dataframe
df <- data.frame(ind=colnames(vcfR@gt)[-1],pop=p)

## write out popmap for stacks
write.table(df, file = "popmap.txt", quote = F, row.names = F, col.names = F, sep = "\t")
```

Use the stacks --phylip-var-all flag to generate the phylip file. Make sure to transfer both the whitelist and popmal files to cluster's working directory. Then, run this script

```bash
#!/bin/sh
#
#SBATCH --job-name=rad.loci                                                    # Job Name
#SBATCH --nodes=1                                                              # Nodes
#SBATCH --ntasks-per-node=1                                                    # CPU allocation per Task
#SBATCH --partition=bi                                                         # Name of the Slurm partition used
#SBATCH --chdir=/home/c889s469/work/projects/ph_agamids/gonocephalus_ddrad     # Set working d$
#SBATCH --mem-per-cpu=5gb                                                      # Memory requested
#SBATCH --time=1000                                                            # Time requested in minutes
#SBATCH --mail-type=ALL                                                        # Mail events (NONE, BEGIN, END, FAIL, ALL)
#SBATCH --mail-user=christian.supsup@ku.edu                                    # Where to send mail

module load stacks

populations -P /home/c889s469/work/projects/ph_agamids/gonocephalus_ddrad/stacks_prelim_outputs -O whitelist/ -M whitelist/iqtree.popmap.txt --whitelist whitelist/whitelist.txt --phylip-var-all

sed '/^#/ d' whitelist/populations.all.phylip > whitelist/radloci_seq.phy
```

Copy both the *pops.phy* and *populations.all.partitions.phylip* files to your local computer. The *pops.phy* file contains the sequences, while *populations.all.partitions.phylip* holds information about loci positions.

```r
####################################
## Covert phylip file to nexus format
####################################
library(ape)
rm(list =ls())

phy.data <- read.dna("data/gono_outgroup_75snps_radloci.phy", format = "interleaved") ## This will not read the data if sequence names are >10 characters
write.nexus.data(phy.data, file = "data/radloci_seq.nex", format = "dna", interleaved = FALSE)

####################################
## Read nexus file
####################################
gono.data <- read.nexus.data("data/radloci_seq.nex")

## Drop samples
gono.data <- gono.data[!(names(gono.data) %in% c("FMNH_26903"))]

## Read the popmap file created above
library(tidyr)
library(dplyr)

## Read popmap. Remember to remove "FM_269032"
gono.info <- read.table("data/iqtree.popmap.txt")

gono.info <- gono.info %>%
  separate(V1, into = c("Genus", "Pop", "Code", "ID"), sep = "_", remove = FALSE)

# If you only want the 'Location' column:
gono.info <- gono.info %>%
  select(V1, V2, Pop)

names(gono.info)[2] <- "ID"

gono.info

## Get samples to keep
samp <- gono.info$ID

## Convert to a matrix
gono.matrix <- as.matrix(gono.data)

## Subset the matrix using setdiff()
diff <- setdiff(rownames(gono.matrix), samp)
diff <- setdiff(rownames(gono.matrix), diff)
gono.sub <- gono.matrix[diff, ]

## Convert to uppercase (lowercase character with "m" or mixed base wont work in iqtree)
gono.upper <- as.data.frame(lapply(gono.sub, function(x) {
  if (is.character(x)) {
    toupper(x)
  } else {
    x  ## leave non-character columns as is
  }
}))

####################################
# Rename samples to add Pop info
####################################
## Read popmap with lineages info
library(vcfR)
popmap <- read.csv("data/gono_popmap.csv")
vcfR<-read.vcfR("data/gono_outgroup_75snps_thinned.vcf")

## Drop samples
# Remove outgroup samples
vcfR <- vcfR[,colnames(vcfR@gt) != "Gonocephalus_Borneo_FMNH_269032"]

matching_ids <- setdiff(colnames(vcfR@gt), "FORMAT")
popmap <- popmap[match(matching_ids, popmap$id), ]
pops <- popmap$pop

## Create a mapping of sequence names to Pops
seq.names <- colnames(gono.upper) 
    
## Check the lengths match
if (length(seq.names) != length(pops)) {
  stop("Mismatch between the number of samples and Pops.")
}

### Append Pop info
colnames(gono.upper) <- paste0(seq.names, "_", pops)

## Check new column names
colnames(gono.upper)

## Check samples incase sample labels are not matchin
#missing_ids <- setdiff(gono.info$ID, colnames(gono.upper))
#missing_ids

####################################
## Get RAD loci
####################################
## Read the whitelist file
whitelist <- scan("data/whitelist.txt")  # contains: 24, 80, 96, 161

## Read the partition file
partition_lines <- readLines("data/gono_outgroup_75snps_partitions.phy")

## Load required library
library(stringr)

## Parse partition info into a data frame
partition_info <- data.frame(
  index = seq_along(partition_lines),
  range = str_extract(partition_lines, "\\d+-\\d+"),
  stringsAsFactors = FALSE
)

## Extract numeric start and end positions
partition_info$start <- as.integer(str_extract(partition_info$range, "^\\d+"))
partition_info$end <- as.integer(str_extract(partition_info$range, "\\d+$"))

## Assign loci numbers to partitions
## Assuming the order of whitelist matches the order of partition lines
partition_info$locus <- whitelist[partition_info$index]

## Create the charsets list: numeric vectors of positions
charsets <- setNames(
  lapply(seq_len(nrow(partition_info)), function(i) {
    range <- partition_info[i, ]
    seq(range$start, range$end)  # Generate vector of positions
  }),
  paste0("locus", partition_info$locus)  # List names like "locus24"
)

## View first few elements
head(charsets)

## Split charset ranges
gono.splits <- lapply(charsets, function(range) {
  gono.upper[range, , drop = FALSE]  ## select rows and all columns
})

## Assign names to each subset
names(gono.splits) <- names(charsets)

## Access each locus
#ND2.matrix <- gono.splits$ND2

## Write a concatenated fasta file of selected genes
#gono.bind <- rbind(gono.splits$PTGER, gono.splits$BDNF, gono.splits$NGFB, 
#  gono.splits$SNCAIP, gono.splits$DGL_alpha, gono.splits$Glor54)

## Randomly sample 10 gene names from the list
#selected_genes <- sample(names(gono.splits), 5)

## Bind the selected genes into one data frame
#gono.bind <- do.call(rbind, gono.splits[selected_genes])

## or Select the first 5
## Select the first 5 gene names from the list
#selected_genes <- names(gono.splits)[1:5]

## Bind the selected genes into one data frame
gono.bind <- do.call(rbind, gono.splits)

## Write the concatenated fasta file
write.dna(gono.bind, file = "data/gono_75snps_radloci.fasta", nbcol = -1, format = "fasta")

####################################
## Rename sample for HHSD analysis
####################################

## Rename by appending numbers to each of the sample (i.e., ACD1500 -> ACD1500^1)
## Function to rename
rename.sample <- function(subset.data) {
  colnames(subset.data) <- paste0(colnames(subset.data), "^", seq_along(colnames(subset.data)))
  return(subset.data)
}

## Apply the renaming function to each subset in gono.splits
gono.splits <- lapply(gono.splits, rename.sample)

####################################
## Write each of locus to a phylip file
####################################

## Output directory
output.dir <- "data/rad_loci" ## this saves to current directory
if (!dir.exists(output.dir)) {
  dir.create(output.dir)
}

## Loop through each subset in gono.splits and write it to a PHYLIP file
for (charset.name in names(gono.splits)) {
  ## Extract the subset
  subset.data <- gono.splits[[charset.name]]
  
  ## define the file name
  file.name <- file.path(output.dir, paste0(charset.name, ".phy"))
  
  ## write the subset to a PHYLIP file
  write.dna(subset.data, file = file.name, format = "sequential", nbcol = -1)

  ## print message confirming file creation
  print(paste("Exported", charset.name, "to", file.name))
}
```
Combine all loci into a one txt file using the bash script below. Save the script as *combine.sh*
```bash
#!/bin/bash

# Check if input directory is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <input_directory>"
    exit 1
fi

input_dir="$1"

# Check if the provided directory exists
if [ ! -d "$input_dir" ]; then
    echo "Error: Directory '$input_dir' does not exist."
    exit 1
fi

# Create an empty combined_seq.txt file
> combined_seq.txt

# Loop through all .phy files in the specified directory
for file in "$input_dir"/*.phy; do
    # Skip if no .phy files are found
    [ -e "$file" ] || continue

    echo "" >> combined_seq.txt
    cat "$file" >> combined_seq.txt
done

echo "Combining files completed."

```
Use the terminal and nagivate to the directory containing all the phylip files use *combine.sh*
```bash
## Allow the combine.sh file to execute
chmod +x combine.sh

## Run the file
./combine.sh
```

**B. Data prep: IMAP file**

Generate the pop map file using the *combined_seq.txt* output with the following bash script. Save the script as *generate_popmap.sh*.
```bash
#!/bin/bash

## Usage check
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <phylip_file> <output_file>"
    exit 1
fi

phylip_file="$1"
output_file="$2"

## Overwrite output
if [ -f "$output_file" ]; then
    echo "Output file '$output_file' already exists. Overwriting..."
fi

## Extract and process sample headers, avoid duplicates
tail -n +2 "$phylip_file" | awk '
{
    header = $1
    if (header ~ /\^/) {
        split(header, parts, "^")
        num = parts[2]

        split(parts[1], id_parts, "_")
        if (length(id_parts) >= 3) {
            pop = id_parts[3]
            for (i = 4; i <= length(id_parts); i++) {
                pop = pop "_" id_parts[i]
            }

            line = num "\t" pop
            if (!seen[line]++) {
                print line
            }
        }
    }
}
' > "$output_file"

echo "Pop map generation completed: $output_file"
```
Execute the script
```bash
## Allow the combine.sh file to execute
chmod +x generate_popmap.sh

## Run the file
./generate_popmap.sh combined_seq.txt gono_hhsd_popmap.txt
```

**C. Data prep: Guide/Initial Tree**

Create a Newick tree for the control file. Use R to visualize the tree and ensure the names match the pop map file.
```r
## Read annotated species tree from starbeast
library(ape)

## Read the tree
tree <- read.nexus("data/gono_75snps_snapp_anno.trees")

## Get the Newick string with branch lengths
sp.tree <- write.tree(tree)

## Remove branch lengths using a regex
sp.tree <- gsub(":([0-9\\.eE+-]+)", "", sp.tree)

## Write output without branch lengths
write(sp.tree, file = "gono_flat_sp_tree.txt")

## Read the string into a tree object
sp.tree <- read.tree(text = sp.tree)

## Check by plotting the tree
plot(sp.tree)
```

**D. Data prep: Control file**

The control file provided with HHSD should be modified accordingly and saved as, say *gono_hhsd_cfile.txt*.

Note that "A11_results" is a folder containing the control file, and it will also serve as the output directory. The *combined_seq.txt* and *popmap.txt* files are located outside of this folder.
```bash
## Output
output_directory = merge_1/

## Input files
Imapfile = gono_popmap.txt
seqfile = combined_seq.txt

## Guide tree
guide_tree = ((Bellii,(((Cebu,Negors_Panay),Mindoro),(Isarog,(Luzon_Polillo,Malinao)))),(Bohol,((Camiguin,SE_Mindanao),((NE_Mindanao,Samar_Leyte),W_Mindanao))));

## Hierarchical algorithm settings
mode = merge
gdi_threshold = <=0.2, <=1.0

## Migration patterns
migration = {Luzon_Polillo <-> Malinao,
    Luzon_Polillo <-> Isarog,
    NE_Mindanao <-> SE_Mindanao,
    NE_Mindanao <-> W_Mindanao,
    W_Mindanao <-> SE_Mindanao}

migprior = 0.1 10

## Other settings
phase = 1
locusrate = 0
cleandata = 0

## MCMC settings
sampfreq = 1
threads = 24
burnin = 5000
nsample = 20000
```

### Run HHSD

Download the software from https://github.com/abacus-gene/hhsd. Ensure everything is set up correctly before running the following command.
```bash
## Run HHSD
hhsd --cfile hhsd_cfile.txt  --cfpor seed = 123, output_directory = merge_res_1
```