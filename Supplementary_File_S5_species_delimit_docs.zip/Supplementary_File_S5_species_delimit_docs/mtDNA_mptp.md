# Gonocephalus ND2 species delimitation using mPTP

### Data Needed
* DNA sequences in nexus format
* Sequences info in csv file

## A. Extract ND2 sequences from Welton et al. (2017)

Obtain Welton et al.'s (2017) Gonocephalus data from http://dx.doi.org/10.5061/dryad.1225k.

```r
## Load packages
rm(list =ls())

library(ape)
library(dplyr)
library(stringr)

## Read nexus file
gono.data <- read.nexus.data("Gono_7gene.nex")

## Read sequence info file
gono.info <- read.csv("welton_select_seq.csv")

####################################
## Covert sequences to a matrix
####################################

## Get samples to keep
samp <- gono.info$Field.No.

## Convert to a matrix
gono.matrix <- as.matrix(gono.data)

## Subset the matrix using setdiff()
diff <- setdiff(rownames(gono.matrix), samp)
diff <- setdiff(rownames(gono.matrix), diff)
gono.sub <- gono.matrix[diff, ]

## Convert to uppercase (lowercase character with "m" or mixed base wont work in iqtree)
gono.upper <- as.data.frame(lapply(gono.sub, function(x) {
  if (is.character(x)) {
    toupper(x)
  } else {
    x  ## Leave non-character columns as is
  }
}))

####################################
## Split according to locus info 
####################################

## identify the range of each locus
charsets <- list(
  ND2 = 1:1015,
  #tRNA = 1016:1226,
  PTGER = 1227:1723,
  BDNF = 1724:2269,
  NGFB = 2270:2781,
  SNCAIP = 2782:3241,
  DGL_alpha = 3242:4280,
  Glor54 = 4281:4701
)

## Split charset ranges
gono.splits <- lapply(charsets, function(range) {
  gono.upper[range, , drop = FALSE]  # select rows and all columns
})

## Sssign names to each subset
names(gono.splits) <- names(charsets)

## Access each locus
ND2.matrix <- gono.splits$ND2

## Drop samples without ND2 sequence and those from the same locality
samp.to.drop <- c("LSUHC4020", "LSUHC4982", "LSUHC6736", 
                  "CDS1766", "CDS1570", "CDS4387", "CDS4339", "CDS4386", 
                  "RMB12659", "RMB9868", "RMB9869", "RMB4103", "RMB10549", 
                  "ACD4593", "RMB10548", "ACD4592", "RMB3706", "ACD866", 
                  "CDS2774", "CDS2863", "CDS4718", "CDS4934", "CDS4720", 
                  "CDS4724", "ACD3804", "RMB11535", "ACD3805", "", 
                  "RMB11529", "RMB9128", "RMB10170", "RMB10095", "RMB10130", 
                  "RMB9385", "RMB11700", "RMB10097", "RMB9388", "RMB10248", 
                  "ACD4019", "ACD3998", "EMD254", "RMB8061", 
                  "RMB8135", "RMB8216", "RMB8249", "CDS5084", 
                  "CDS5511", "CDS5089", "ACD5158", "ACD5457", "ACD5282", 
                  "ACD5327", "CDS5510", "ACD4143")

ND2.matrix <- ND2.matrix[, !(colnames(ND2.matrix) %in% samp.to.drop)]

####################################
## Rename sequences
####################################

## Clean Museum.No. (remove spaces)
gono.info <- gono.info %>%
  mutate(Museum.No. = str_replace_all(Museum.No., " ", ""))

## Build lookup
lookup_table <- gono.info %>%
  select(Field.No., Museum.No., Lineage)

## Create new column names
new_colnames <- sapply(colnames(ND2.matrix), function(colname) {
  match_row <- lookup_table %>% filter(Field.No. == colname)
  
  if (nrow(match_row) == 1) {
    museum_no <- match_row$Museum.No.
    lineage <- match_row$Lineage
    
    if (!is.na(museum_no) && museum_no != "") {
      paste0(museum_no, "_", lineage)
    } else {
      paste0(colname, "_", lineage)
    }
  } else {
    paste0(colname, "_Unknown")
  }
})

## Apply new names to gono.upper
colnames(ND2.matrix) <- new_colnames

####################################
## Write files
####################################
ND2.matrix.char <- as.data.frame(lapply(ND2.matrix, as.character))

write.nexus.data(ND2.matrix.char, file = "gono_ND2.nex", interleaved = FALSE)

## write to a fasta file
gono.nd2 <- read.nexus.data("gono_ND2.nex")

write.dna(gono.nd2, file = "gono_ND2.fasta", nbcol = -1, format = "fasta")

####################################
## Align fasta file
####################################
library(muscle)

## Read fasta file
gono.fasta <- readDNAStringSet("gono_ND2.fasta", format = "fasta")

## Align using muscle
gono.aln <- muscle(gono.fasta, diags = TRUE)

## Extract dna stringset
gono.set <- unmasked(gono.aln)

## Write to a fasta file
writeXStringSet(dna_set, "gono_ND2_aln.fasta")
```

## B. Run iqtree and mptp
```bash

####################################
## Run iqtree
####################################
iqtree2 -s gono_ND2_aln.nexus -p gono_ND2_partition.nex -B 1000 -m MFP+MERGE -T AUTO -safe -redo

####################################
## Run mptp
####################################
mptp --tree_file gono_ND2_partition.nex.contree --output_file gono_spdelimit_ML --ml --multi --minbr 0.0010106987 --outgroup LSUHC6706,LSUHC6735

## Find minimum branch length
mptp --tree_file gono_ND2_partition.nex.contree \
   --minbr_auto gono_ND2.fasta \
   --output_file gono_delimit \
   --outgroup LSUHC6706_Bellii,LSUHC6735_Bellii

## Run with ML
mptp --tree_file gono_ND2_partition.nex.contree \
   --output_file gono_spdelimit_ML \
   --ml --multi \
   --minbr  0.0010095330 \
   --outgroup LSUHC6706_Bellii,LSUHC6735_Bellii

## Run with MCMC
mptp --tree_file gono_ND2_partition.nex.contree \
   --output_file gono_spdelimit_mcmc \
   --multi \
   --minbr 0.0010095330 \
   --mcmc 10000000 \
   --mcmc_runs 2 \
   --mcmc_burnin 1000000 \
   --outgroup LSUHC6706_Bellii,LSUHC6735_Bellii
```
