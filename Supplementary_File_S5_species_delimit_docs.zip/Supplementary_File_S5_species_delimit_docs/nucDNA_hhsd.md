# Hierarchical heuristic species delimitation (HHSD)

### Data Needed
* DNA sequences
* Pop map file
* Guide tree
* Control file

**A. Data prep: DNA sequences in Phylip format**

Obtain Welton et al.'s (2017) Gonocephalus data from http://dx.doi.org/10.5061/dryad.1225k. Then, subset it in R to get only the nuclear genes.

```r
## Load package 
library(ape)
rm(list =ls())

####################################
## Read nexus file
####################################
gono.data <- read.nexus.data("Gono_7gene.nex")

## Read sequence info file
gono.info <- read.csv("welton_select_seq.csv") # Make sure to remove G. bornensis as this only has one sample

## Get samples to keep
samp <- gono.info$Field.No.

## Convert to a matrix
gono.matrix <- as.matrix(gono.data)

## Subset the matrix using setdiff()
diff <- setdiff(rownames(gono.matrix), samp)
diff <- setdiff(rownames(gono.matrix), diff)
gono.sub <- gono.matrix[diff, ]

## Convert to uppercase (lowercase character with "m" or mixed base wont work in iqtree)
gono.upper <- as.data.frame(lapply(gono.sub, function(x) {
  if (is.character(x)) {
    toupper(x)
  } else {
    x  ## leave non-character columns as is
  }
}))

####################################
# Rename samples to add lineage info
####################################
## Get field number and taxon columns
gono.lab <- gono.info[3:5]

colnames(gono.lab)

## Sort field number and expand to other columns
gono.sort <- gono.lab[order(gono.lab$Field.No.), ]

## Check if the DNA sequence names are matching
gono.sort.lab <- gono.sort$Field.No.
gono.upper.lab <- colnames(gono.upper)
length(unique(gono.sort.lab)) == length(gono.upper.lab)

## Create a mapping of sequence names to lineages
seq.names <- colnames(gono.upper) 
lineages <- gono.sort$Lineage        

## Check the lengths match
if (length(seq.names) != length(lineages)) {
  stop("Mismatch between the number of samples and lineages.")
}

### Append lineage info
colnames(gono.upper) <- paste0(seq.names, "_", lineages)

## Check new column names
colnames(gono.upper)

####################################
## Get nuclear genes
####################################
## Identify the range of each locus
charsets <- list(
  #ND2 = 1:1015,
  #tRNA = 1016:1226,
  PTGER = 1227:1723,
  BDNF = 1724:2269,
  NGFB = 2270:2781,
  SNCAIP = 2782:3241,
  DGL_alpha = 3242:4280,
  Glor54 = 4281:4701
)

## Split charset ranges
gono.splits <- lapply(charsets, function(range) {
  gono.upper[range, , drop = FALSE]  ## select rows and all columns
})

## Assign names to each subset
names(gono.splits) <- names(charsets)

## Access each locus
#ND2.matrix <- gono.splits$ND2

## Write a concatenated fasta file of selected genes
gono.bind <- rbind(gono.splits$PTGER, gono.splits$BDNF, gono.splits$NGFB, 
  gono.splits$SNCAIP, gono.splits$DGL_alpha, gono.splits$Glor54)

write.dna(gono.bind, file = "gono_6nucgenes.fasta", nbcol = -1, format = "fasta")

####################################
## Rename sample for HHSD analysis
####################################

## Rename by appending numbers to each of the sample (i.e., ACD1500 -> ACD1500^1)

## Function to rename
rename.sample <- function(subset.data) {
  colnames(subset.data) <- paste0(colnames(subset.data), "^", seq_along(colnames(subset.data)))
  return(subset.data)
}

## Apply the renaming function to each subset in gono.splits
gono.splits <- lapply(gono.splits, rename.sample)

####################################
## Write each of locus to a phylip file
####################################

## Output directory
output.dir <- "." ## this saves to current directory
if (!dir.exists(output.dir)) {
  dir.create(output.dir)
}

## Loop through each subset in gono.splits and write it to a PHYLIP file
for (charset.name in names(gono.splits)) {
  ## Extract the subset
  subset.data <- gono.splits[[charset.name]]
  
  ## define the file name
  file.name <- file.path(output.dir, paste0(charset.name, ".phy"))
  
  ## write the subset to a PHYLIP file
  write.dna(subset.data, file = file.name, format = "sequential", nbcol = -1)

  ## print message confirming file creation
  print(paste("Exported", charset.name, "to", file.name))
}
```
Combine all loci into a one txt file using the bash script below. Save the script as *combine.sh*
```bash
#!/bin/bash

## Create an empty combined_seq.txt file
> combined_seq.txt

# loop through all .phy files in the current directory
for file in *.phy; do
    # Skip if no .phy files are found
    [ -e "$file" ] || continue
    
    echo "" >> combined_seq.txt

    # append the entire content of the .phy file to combined_seq.txt
    cat "$file" >> combined_seq.txt
done

echo "Combining files completed."
```
Use the terminal and nagivate to the directory containing all the phylip files use *combine.sh*
```bash
## Allow the combine.sh file to execute
chmod +x combine.sh

## Run the file
./combine.sh
```

**B. Data prep: IMAP file**

Generate the pop map file using the *combined_seq.txt* output with the following bash script. Save the script as *generate_popmap.sh*.
```bash
#!/bin/bash

## Usage check
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <phylip_file> <output_file>"
    exit 1
fi

phylip_file="$1"
output_file="$2"

## Overwrite output
if [ -f "$output_file" ]; then
    echo "Output file '$output_file' already exists. Overwriting..."
fi

## Extract and process sample headers, avoid duplicates
tail -n +2 "$phylip_file" | awk '
{
    header = $1
    if (header ~ /\^/) {
        split(header, parts, "^")
        num = parts[2]

        split(parts[1], id_parts, "_")
        pop = id_parts[2]
        for (i = 3; i <= length(id_parts); i++) {
            pop = pop "_" id_parts[i]
        }

        line = num "\t" pop
        if (!seen[line]++) {
            print line
        }
    }
}
' > "$output_file"

echo "Pop map generation completed: $output_file"
```
Execute the script
```bash
## Allow the combine.sh file to execute
chmod +x generate_popmap.sh

## Run the file
./generate_popmap.sh combined_seq.txt popmap.txt
```

**C. Data prep: Guide/Initial Tree**

Create a Newick tree for the control file. Use R to visualize the tree and ensure the names match the pop map file.
```r
## Read annotated species tree from starbeast
library(ape)

## Read the tree
tree <- read.nexus("species_anno.trees")

## Get the Newick string with branch lengths
sp.tree <- write.tree(tree)

## Remove branch lengths using a regex
sp.tree <- gsub(":([0-9\\.eE+-]+)", "", sp.tree)

## Write output without branch lengths
write(sp.tree, file = "gono_flat_sp_tree.txt")

## Read the string into a tree object
sp.tree <- read.tree(text = sp.tree)

## Check by plotting the tree
plot(sp.tree)
```

**D. Data prep: Control file**

The control file provided with HHSD should be modified accordingly and saved as, say *gono_hhsd_cfile.txt*.

Note that "A11_results" is a folder containing the control file, and it will also serve as the output directory. The *combined_seq.txt* and *popmap.txt* files are located outside of this folder.
```bash
## Output
output_directory = merge_1/

## Input files
Imapfile = gono_popmap.txt
seqfile = combined_seq.txt

## Guide tree
guide_tree = ((Bellii,(((Cebu,Negors_Panay),Mindoro),(Isarog,(Luzon_Polillo,Malinao)))),(Bohol,((Camiguin,SE_Mindanao),((NE_Mindanao,Samar_Leyte),W_Mindanao))));

## Hierarchical algorithm settings
mode = merge
gdi_threshold = <=0.2, <=1.0

## Migration patterns
migration = {Luzon_Polillo <-> Malinao,
    Luzon_Polillo <-> Isarog,
    NE_Mindanao <-> SE_Mindanao,
    NE_Mindanao <-> W_Mindanao,
    W_Mindanao <-> SE_Mindanao}

migprior = 0.1 10

## Other settings
phase = 1
locusrate = 0
cleandata = 0

## MCMC settings
sampfreq = 1
threads = 4
burnin = 2000
nsample = 5000
```

### Run HHSD

Download the software from https://github.com/abacus-gene/hhsd. Ensure everything is set up correctly before running the following command.
```bash
## Run HHSD
hhsd --cfile hhsd_cfile.txt  --cfpor seed = 123, output_directory = merge_res_1
```