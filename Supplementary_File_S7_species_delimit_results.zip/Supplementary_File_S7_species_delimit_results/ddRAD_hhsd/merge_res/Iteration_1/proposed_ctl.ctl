seed=52536
seqfile=/home/c889s469/Documents/gono_hhsd/gono_radloci.txt
Imapfile=proposed_imap.txt
outfile=proposal_bpp_out.txt
mcmcfile=proposal_bpp_mcmc.txt
speciesdelimitation=0
speciestree=0
species&tree=14 PMalaysia Mindoro Romblon NE_Mindanao Camiguin Cebu Negros_Panay Malinao Bohol Samar_Leyte SE_Mindanao W_Mindanao Isarog Luzon_Polillo
               2  7  2  8  6  3  9  1  5  8  5  6  2  16
               (((((Bohol,Samar_Leyte),NE_Mindanao),(Camiguin,(SE_Mindanao,W_Mindanao))),PMalaysia),(((Cebu,Negros_Panay),((Isarog,Luzon_Polillo),Malinao)),(Mindoro,Romblon)));
phase=1 1 1 1 1 1 1 1 1 1 1 1 1 1 
usedata=1
nloci=100
locusrate=0
cleandata=0
thetaprior=3 0.04 e
tauprior=3 0.02
finetune=1: .01 .0001 .005 .0005 .2 .01 .01 .01
print=1 0 0 0
burnin=5000
sampfreq=1
nsample=20000
threads=24
migprior=0.1 10
migration = 10
	Luzon_Polillo Malinao
	Malinao Luzon_Polillo
	Luzon_Polillo Isarog
	Isarog Luzon_Polillo
	NE_Mindanao SE_Mindanao
	SE_Mindanao NE_Mindanao
	NE_Mindanao W_Mindanao
	W_Mindanao NE_Mindanao
	W_Mindanao SE_Mindanao
	SE_Mindanao W_Mindanao
