seed=52536
seqfile=/home/c889s469/Documents/gono_hhsd/gono_radloci.txt
Imapfile=proposed_imap.txt
outfile=proposal_bpp_out.txt
mcmcfile=proposal_bpp_mcmc.txt
speciesdelimitation=0
speciestree=0
species&tree=11 PMalaysia Mindoro Romblon NE_Mindanao Camiguin Cebu Negros_Panay Malinao BoholSamar_Leyte SE_MindanaoW_Mindanao IsarogLuzon_Polillo
               2  7  2  8  6  3  9  1  13  11  18
               ((((BoholSamar_Leyte,NE_Mindanao),(Camiguin,SE_MindanaoW_Mindanao)),PMalaysia),(((Cebu,Negros_Panay),(IsarogLuzon_Polillo,Malinao)),(Mindoro,Romblon)));
phase=1 1 1 1 1 1 1 1 1 1 1 
usedata=1
nloci=100
locusrate=0
cleandata=0
thetaprior=3 0.04 e
tauprior=3 0.02
finetune=1: .01 .0001 .005 .0005 .2 .01 .01 .01
print=1 0 0 0
burnin=5000
sampfreq=1
nsample=20000
threads=24
migprior=0.1 10
migration = 4
	IsarogLuzon_Polillo Malinao
	Malinao IsarogLuzon_Polillo
	NE_Mindanao SE_MindanaoW_Mindanao
	SE_MindanaoW_Mindanao NE_Mindanao
